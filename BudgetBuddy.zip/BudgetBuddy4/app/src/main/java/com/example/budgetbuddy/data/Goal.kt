package com.example.budgetbuddy.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "min_goal") val minGoal: Double,
    @ColumnInfo(name = "max_goal") val maxGoal: Double
)

// HomeScreen.kt
package com.example.budgetbuddy.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun HomeScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome to Budget Buddy", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { navController.navigate("setBudgetGoals") }, modifier = Modifier.fillMaxWidth()) {
            Text("Set Budget Goals")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("trackExpense") }, modifier = Modifier.fillMaxWidth()) {
            Text("Track Expense")
        }
    }
}
package com.example.budgetbuddy.viewmodel

import com.example.budgetbuddy.model.User

class UserRepository {

    private val users = mutableListOf<User>()  // In-memory list to store users.

    // Register method
    fun register(username: String, password: String): Boolean {
        // Check if user already exists
        if (users.any { it.username == username }) {
            return false  // User already exists
        }
        // Add new user
        users.add(User(username = username, password = password))
        return true
    }

    // Login method
    fun login(username: String, password: String): Boolean {
        return users.any { it.username == username && it.password == password }
    }
}

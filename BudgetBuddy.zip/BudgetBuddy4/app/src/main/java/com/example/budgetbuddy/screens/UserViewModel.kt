package com.example.budgetbuddy.viewmodel

import androidx.lifecycle.ViewModel
import com.example.budgetbuddy.model.User

class UserViewModel(private val repository: UserRepository) : ViewModel() {

    fun register(username: String, password: String): Boolean {
        return repository.register(username, password)
    }

    fun login(username: String, password: String): Boolean {
        return repository.login(username, password)
    }
}

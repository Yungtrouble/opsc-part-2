package com.example.budgetbuddy.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.budgetbuddy.screens.RegisterScreen
import com.example.budgetbuddy.screens.LoginScreen
import com.example.budgetbuddy.screens.HomeScreen
import com.example.budgetbuddy.screens.SetBudgetGoalScreen
import com.example.budgetbuddy.screens.TrackExpenseScreen

@Composable
fun AppNavigation(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "register") {
        composable("register") { RegisterScreen(navController) }
        composable("login") { LoginScreen(navController) }
        composable("home") { HomeScreen(navController) }
        composable("setBudgetGoal") { SetBudgetGoalScreen(navController) }
        composable("trackExpense") { TrackExpenseScreen(navController) }

    }
}

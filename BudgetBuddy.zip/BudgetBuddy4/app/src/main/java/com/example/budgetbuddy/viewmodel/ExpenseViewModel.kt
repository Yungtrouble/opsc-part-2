package com.example.budgetbuddy.viewmodel

import androidx.lifecycle.ViewModel
import com.example.budgetbuddy.model.Expense

class ExpenseViewModel : ViewModel() {
    // In-memory list to store expenses
    private val expenses = mutableListOf<Expense>()

    // Function to add an expense
    fun addExpense(expense: Expense) {
        expenses.add(expense)
    }

    // Function to retrieve all expenses
    fun getExpenses(): List<Expense> = expenses
}

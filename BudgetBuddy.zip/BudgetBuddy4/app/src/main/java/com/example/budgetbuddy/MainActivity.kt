// MainActivity.kt
package com.example.budgetbuddy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.budgetbuddy.screens.*
import com.example.budgetbuddy.ui.theme.BudgetBuddyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BudgetBuddyTheme {
                BudgetBuddyApp()
            }
        }
    }
}

@Composable
fun BudgetBuddyApp() {
    val navController = rememberNavController()
    BudgetBuddyNavHost(navController)
}

@Composable
fun BudgetBuddyNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "register") {
        composable("register") { RegisterScreen(navController) }
        composable("login") { LoginScreen(navController) }
        composable("home") { HomeScreen(navController) }
        composable("setBudgetGoals") { SetBudgetGoalScreen(navController) }
        composable("trackExpense") { TrackExpenseScreen(navController) }
    }
}

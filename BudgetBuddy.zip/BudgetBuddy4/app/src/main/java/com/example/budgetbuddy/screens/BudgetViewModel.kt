package com.example.budgetbuddy.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Expense(val name: String, val amount: Double)

class BudgetViewModel : ViewModel() {
    private val _budgetGoal = MutableStateFlow(0.0)
    val budgetGoal = _budgetGoal.asStateFlow()

    private val _expenses = MutableStateFlow<List<Expense>>(emptyList())
    val expenses = _expenses.asStateFlow()

    fun setBudgetGoal(amount: Double) {
        _budgetGoal.value = amount
    }

    fun addExpense(name: String, amount: Double) {
        _expenses.value = _expenses.value + Expense(name, amount)
    }

    fun totalExpenses(): Double {
        return _expenses.value.sumOf { it.amount }
    }

    fun remainingBudget(): Double {
        return _budgetGoal.value - totalExpenses()
    }
}

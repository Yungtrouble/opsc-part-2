package com.example.budgetbuddy.dao

import androidx.room.*
import com.example.budgetbuddy.model.Goal

@Dao
interface GoalDao {
    @Insert
    suspend fun insertGoal(goal: Goal)

    @Query("SELECT * FROM goals")
    suspend fun getAllGoals(): List<Goal>
}

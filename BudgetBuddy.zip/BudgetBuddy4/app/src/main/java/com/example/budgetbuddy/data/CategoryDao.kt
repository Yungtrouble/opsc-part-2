package com.example.budgetbuddy.dao

import androidx.room.*
import com.example.budgetbuddy.model.Category

@Dao
interface CategoryDao {
    @Insert
    suspend fun insertCategory(category: Category)

    @Query("SELECT * FROM categories")
    suspend fun getAllCategories(): List<Category>
}

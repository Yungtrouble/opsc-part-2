
package com.example.budgetbuddy.screens

import android.util.Patterns
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.budgetbuddy.viewmodel.UserRepository
import kotlinx.coroutines.launch

@Composable
fun RegisterScreen(navController: NavHostController) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val userRepository = remember { UserRepository() }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Welcome message
        Text(
            text = "Welcome to Budget Buddy App!",
            style = MaterialTheme.typography.h5,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Text("Register", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(16.dp))

        // Email field
        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Password field
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Register button
        Button(onClick = {
            errorMessage = "" // Reset error message

            when {
                username.isBlank() || password.isBlank() -> {
                    errorMessage = "Please fill in both fields"
                }
                !Patterns.EMAIL_ADDRESS.matcher(username).matches() -> {
                    errorMessage = "Enter a valid email address"
                }
                password.length < 6 -> {
                    errorMessage = "Password must be at least 6 characters"
                }
                else -> {
                    coroutineScope.launch {
                        val success = userRepository.register(username, password)
                        if (success) {
                            navController.navigate("login") // Navigate to login screen
                        } else {
                            errorMessage = "User already exists or registration failed"
                        }
                    }
                }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Register")
        }

        // Navigation to login screen
        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = { navController.navigate("login") }) {
            Text("Already have an account? Login")
        }

        // Display error message if any
        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(errorMessage, color = MaterialTheme.colors.error)
        }
    }
}

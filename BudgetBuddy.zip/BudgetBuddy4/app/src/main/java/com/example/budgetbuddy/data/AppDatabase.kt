package com.example.budgetbuddy.data

import android.content.Context
import androidx.room.*
import com.example.budgetbuddy.model.BudgetGoal
import com.example.budgetbuddy.model.Expense
import com.example.budgetbuddy.model.User

@Database(
    entities = [User::class, Expense::class, BudgetGoal::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "budget_buddy_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }

    // Optional: You can define abstract fun userDao(): UserDao if needed later
}

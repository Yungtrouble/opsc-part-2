
// SetBudgetGoalsScreen.kt
package com.example.budgetbuddy.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun SetBudgetGoalScreen(navController: NavHostController)
 {
    var minGoal by remember { mutableStateOf("") }
    var maxGoal by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Set Monthly Budget Goals", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(value = minGoal, onValueChange = { minGoal = it }, label = { Text("Minimum Budget Goal") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = maxGoal, onValueChange = { maxGoal = it }, label = { Text("Maximum Budget Goal") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("home") }, modifier = Modifier.fillMaxWidth()) {
            Text("Save Budget Goals")
        }
    }
}